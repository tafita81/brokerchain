# Broker de Conformidade Viva – Versão Braskem e Armazéns (Replit)

Este projeto é uma evolução do template **BCV** (Broker de Conformidade Viva).
Agora, ele integra as três frentes de monetização — **PFAS/EPR nos EUA**, **Buy America**
e **EUDR** — com um ecossistema completo de fornecedores globais (Brasil, EUA, Europa e
Ásia) e armazéns estratégicos em São Paulo e nos Estados Unidos. Além da Braskem,
inclui fabricantes de embalagens compostáveis, fixadores 100 % “melted and manufactured in USA”
e cooperativas de commodities rastreáveis. O projeto expõe uma API em português e foi
concebido para ser plug‑and‑play no Replit, permitindo monetizar rapidamente ao
atuar como broker B2B de conformidade.

## Principais recursos

* **FastAPI** com endpoints REST claros para ingestão de fornecedores, geração
  de RFQs, verificação regulatória e emissão de passaportes digitais (DPP).
* **Conectores modulares** em `connectors/` que permitem plugar novas
  plataformas e fornecedores sem alterar a lógica principal. Esta versão inclui:
  * Fornecedores **PFAS/EPR**: além da **Braskem**, incorporamos **Bioleader** e
    **Vegware** (embalagens de bagasse, amido e fibra moldada, todas sem PFAS
    e certificadas para compostagem【732713063189336†L40-L83】【246364944531829†L27-L57】),
    **SunDance** (embalagens biodegradáveis e recicláveis, atendendo leis
    estaduais de PFAS【265083869860939†L492-L510】), **Sabert** (potes de polpa
    natural, linhas Standard/Pulp Plus/Pulp Max, PFAS‑free【148223364329520†L0-L26】【148223364329520†L40-L74】) e **ChemGreen**.
  * Fornecedores **Buy America**: **Dyson** e **Prestige Stamping** fornecem
    parafusos e arruelas de grande diâmetro totalmente fundidos e fabricados nos EUA,
    garantindo conformidade com Buy America e certificações IATF/ISO【262551720232303†L65-L110】.
  * Fornecedores **EUDR**: cooperativas e empresas brasileiras como **Sancoffee**
    (café com polígonos georreferenciados e rastreabilidade【447438984867082†L43-L128】),
    **Suzano** e **Klabin** (celulose certificada livre de desmatamento【537191952811551†L464-L577】).
  * **warehouse.py** – modela interações com armazéns externos. Os exemplos
    incluídos usam **Logistics Plus**: um armazém em São Paulo (Água Branca) com
    mais de 2 000 posições de pallets, WMS, temperatura controlada e licenças para
    saúde/cosméticos【151261345310366†L296-L324】; e um armazém nos EUA que você
    pode configurar conforme sua 3PL. A arquitetura suporta múltiplos depósitos e
    cross‑docking: pedidos sempre entram via fornecedores e são enviados aos hubs
    para consolidação antes de seguir ao cliente, garantindo controle de qualidade.
  * Conector HTTP genérico (`http_generic.py`) para integrar qualquer API via
    webhooks declarados em `providers.yaml`.
* **Bandit Thompson Sampling** em `bandit.py`, copiado e adaptado do pacote
  `quantum_broker_FULL_WITH_TESTS.zip`, para selecionar automaticamente o
  melhor template de RFQ conforme o histórico de respostas.
* **Gerador de passaportes digitais (DPP)** para EUDR, que cria PDFs com
  informações de georreferenciamento usando ReportLab.
* **Roteiro logístico inteligente**: a rota `/logistics/route` indica
  automaticamente se a mercadoria deve passar pelo hub de São Paulo ou dos
  Estados Unidos, garantindo que todo produto seja cross‑dockado e
  inspecionado antes de seguir ao comprador final.
* **Aprendizado contínuo**: o BCV registra o sucesso ou falha de cada RFQ via
  algoritmo de *Thompson Sampling* e ajusta a probabilidade de escolha dos
  templates. Se você fornecer uma `OPENAI_API_KEY` e configurar variáveis
  de ambiente, pode integrar o ChatGPT para analisar respostas de clientes,
  classificar como sucesso/fracasso e gerar sugestões de melhoria. Isso
  possibilita evolução constante sem intervenção manual.
* **Integração com Stripe e Payoneer**: o módulo de pagamentos foi pensado
  para que você nunca precise investir capital próprio. As comissões são
  cobradas via Stripe (PaymentIntent com captura manual) e podem ser
  repassadas automaticamente para sua conta Payoneer usando variáveis de
  ambiente (`PAYONEER_API_KEY`, `PAYONEER_ACCOUNT_ID`, `PAYONEER_PAYOUT_URL`).
  A função `payoneer_payout()` em `main.py` demonstra como invocar a API
  do Payoneer para receber sua comissão sem expor dados bancários.

* **Associações e programas de financiamento**: arquivos YAML (`associations.yaml` e
  `funding.yaml`) enumeram grupos como Sustainable Packaging Coalition (SPC),
  NMSDC, GS1 US/Brasil e coalizões brasileiras de embalagens sustentáveis, além
  de oportunidades de financiamento como o SBIR da EPA, grants de Prevenção
  da Poluição (P2) e iniciativas da MBDA. Há endpoints e páginas HTML (`/associations`,
  `/funding`) que exibem esses dados e ajudam a planejar a adesão a
  associações e a busca por verbas.
* **Alertas via Slack, Telegram ou e‑mail** configuráveis através de variáveis
  de ambiente.

* **Páginas HTML integradas**: além dos endpoints de API, esta versão
  inclui páginas web navegáveis para compradores e fornecedores. A
  página inicial (``/``) apresenta o modelo de negócios e links para
  cada frente: ``/pfas`` para embalagens PFAS/EPR, ``/buyamerica`` para
  produtos Buy America e ``/eudr`` para commodities EUDR. Cada página
  descreve os fornecedores certificados e contém links para métricas ao vivo
  (``/metrics/pfas``, ``/metrics/buyamerica``, ``/metrics/eudr``). As
  métricas são atualizadas em tempo real pelo backend e mostram
  quantos RFQs foram enviados, quantas respostas foram recebidas e
  quantas negociações foram concluídas com sucesso.

  Há ainda uma página **Plano Estratégico** (``/strategy``) que
  resume a sequência de ações recomendadas antes de iniciar vendas:
  adesão a associações (SPC, NMSDC, GS1), inscrição em programas de
  financiamento (SBIR, P2, SBDC/MBDA, Horizon Europe), preparação do
  ambiente digital no Replit, onboarding de fornecedores/compradores e
  inovação contínua. Use esta página como guia para planejar seus
  primeiros passos e maximizar credibilidade.

* **Controle de e‑mails Hostinger (envio e leitura)**: configure as
  variáveis `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS` para envio e
  `IMAP_HOST`, `IMAP_USER`, `IMAP_PASS` para leitura. O endpoint
  ``/messages/inbox`` lista as últimas mensagens recebidas no seu
  domínio Hostinger. Assim, o sistema pode negociar via e‑mail quando
  integrações de API não estiverem disponíveis ou falharem, mantendo
  comunicação centralizada.

* **Negociação e termos zero‑risco**: a rota `/negotiate` permite solicitar prazos de pagamento (ex.: Net30/Net45) e a transferência de todos os custos de extravio, desistência ou danos para o fornecedor. O sistema tenta negociar via API (`api_negotiation_url` em `providers.yaml`) e, em caso de indisponibilidade, recorre a e‑mails gerados automaticamente pelo ChatGPT. Assim, você lucra sem precisar investir capital próprio e elimina o risco financeiro.
* **Campos de pagamento e risco**: as requisições de RFQ (`/rfq`) e de negociação aceitam os campos opcionais `payment_terms` e `risk_assumption`; se omitidos, são preenchidos automaticamente com os valores padrão definidos no `providers.yaml`.
* **Integração Payoneer/Stripe**: embora o projeto use Stripe para gerar PaymentIntents, você pode apontar o repasse da comissão para sua conta Payoneer. Isso permite receber comissões sem desembolsar recursos para financiar as compras.

## Estrutura de arquivos

```
bcv_braskem_replit/
│   README.md            ← documentação (este arquivo)
│   main.py              ← API FastAPI com rotas principais
│   bandit.py            ← algoritmo Thompson Sampling para seleção de templates
│   compliance.py        ← regras PFAS/EPR/Buy America/EUDR e utilidades
│   prompts.py           ← prompts para RFQs e DPPs
│   providers.yaml       ← configuração declarativa dos conectores
│   requirements.txt     ← dependências de Python
│   .env.example         ← exemplo de variáveis de ambiente
│   .replit              ← configura o comando de execução no Replit
│
└── connectors/
    │   __init__.py
    │   base.py         ← classe base para conectores
    │   email.py        ← envio de RFQs por e‑mail
    │   http_generic.py ← conector genérico para webhooks/REST
    │   warehouse.py    ← integra armazéns (SP e USA)
    │   braskem.py      ← obtém catálogo de produtos Braskem
        └── data/
        │   ├── braskem_products.json ← catálogo Braskem
        │   └── chemgreen_products.json ← catálogo ChemGreen
```

## Como usar

1. **Crie um Repl** em replit.com (Python) e faça upload da pasta `bcv_braskem_replit`.
2. Copie `.env.example` para `.env` e preencha:
   - `OPENAI_API_KEY`, `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS` (caso envie e‑mails).
   - `STRIPE_API_KEY` e `STRIPE_CURRENCY` para pagamentos.
   - `BASIC_AUTH_USER` e `BASIC_AUTH_PASS` para proteger rotas sensíveis.
   - `SLACK_WEBHOOK` e/ou `TELEGRAM_WEBHOOK` se desejar alertas.
3. Instale dependências: `pip install -r requirements.txt` (o Replit faz isso
   automaticamente). Se desejar PDF com caracteres asiáticos, instale
   `reportlab==4.1.0`.
4. Execute com `uvicorn main:app --host 0.0.0.0 --port 8000 --proxy-headers` (já
   configurado em `.replit`). Visite `/docs` para ver a documentação interativa.
5. Use as rotas:
   - **/suppliers/{supplier}/products** (GET, autenticado) – retorna o catálogo do
     fornecedor especificado (por exemplo, `braskem` ou `chemgreen`) com flags
     PFAS/EPR/Buy America calculadas a partir dos dados de cada item【80386828047739†L160-L167】.
   - **/warehouse/list** (GET) – lista metadados dos armazéns (SP e USA) com
     capacidade e localização【151261345310366†L296-L324】.
   - **/warehouse/pull_orders** (GET, autenticado) – coleta pedidos dos
     armazéns configurados (exemplo genérico; adapte conforme API).
   - **/rfq** (POST) – cria uma RFQ, seleciona o melhor template via bandit
     e envia por e‑mail ou webhook.
   - **/negotiate** (POST) – negocia termos de pagamento e assunção de riscos com um fornecedor. Tenta usar a API do fornecedor e, se não houver, envia e‑mail automático com suporte do ChatGPT.
   - **/eudr/trace** (POST) – gera passaporte digital (DPP) em PDF para um lote.

## Fontes de referência

* **Braskem** – Líder em biopolímeros, introduziu em 2025 filmes MDO de
  polietileno bio‑baseado com cana‑de‑açúcar que possibilitam embalagens
  mono‑material recicláveis, alinhadas à economia circular【80386828047739†L160-L169】.  
* **Logistics Plus São Paulo** – inaugurou em julho de 2025 um armazém em
  Água Branca (SP) com capacidade para mais de 2 000 posições de pallets,
  WMS integrável, armazenamento com temperatura controlada e licenças para
  produtos de saúde e cosméticos【151261345310366†L296-L324】.  
* **Logística e frota Braskem** – em julho de 2025 a Braskem ampliou sua
  frota de navios com o etaneiro **Brave Future**, aumentando a autonomia
  logística e reduzindo custos de transporte entre EUA, México e Brasil【29619735909851†L144-L170】.

Para mais detalhes sobre cada fonte, consulte as seções e citações incluídas no
relatório fornecido ao usuário.