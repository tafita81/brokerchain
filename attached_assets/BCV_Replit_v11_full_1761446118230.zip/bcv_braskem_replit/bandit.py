"""Módulo de Thompson Sampling para seleção de templates de RFQ.

Este módulo implementa uma versão simplificada do algoritmo multi‑armed bandit
usando distribuição Beta. Em vez de persistir os parâmetros em um banco de
dados, os valores de `alpha` e `beta` para cada template são armazenados em
um arquivo JSON (`bandit_state.json`). Isso facilita o uso no Replit sem
dependências extras.

Cada template do arquivo `prompts.py` deve ter um campo `id`. O arquivo
`bandit_state.json` será criado automaticamente na primeira execução com
valores iniciais `alpha=1` e `beta=1` para cada template.
"""

from __future__ import annotations

import json
import os
import random
from typing import Dict, Any

from prompts import RFQ_TEMPLATES

STATE_FILE = os.getenv("BANDIT_STATE_FILE", "bandit_state.json")


def _load_state() -> Dict[str, Dict[str, float]]:
    """Carrega (ou inicializa) o estado dos parâmetros para cada template.

    Retorna um dicionário com a estrutura {template_id: {"alpha": a, "beta": b}}.
    """
    # Se o arquivo não existe, inicializa com valores padrão
    if not os.path.exists(STATE_FILE):
        state = {tpl["id"]: {"alpha": 1.0, "beta": 1.0} for tpl in RFQ_TEMPLATES}
        with open(STATE_FILE, "w") as fp:
            json.dump(state, fp)
        return state
    # Caso exista, tenta carregar
    try:
        with open(STATE_FILE, "r") as fp:
            state: Dict[str, Dict[str, float]] = json.load(fp)
    except Exception:
        # Em caso de corrupção do arquivo, reinicia
        state = {tpl["id"]: {"alpha": 1.0, "beta": 1.0} for tpl in RFQ_TEMPLATES}
        with open(STATE_FILE, "w") as fp:
            json.dump(state, fp)
    # Garante que todos templates tenham entradas
    for tpl in RFQ_TEMPLATES:
        if tpl["id"] not in state:
            state[tpl["id"]] = {"alpha": 1.0, "beta": 1.0}
    return state


def _save_state(state: Dict[str, Dict[str, float]]) -> None:
    """Salva o estado para o arquivo JSON."""
    with open(STATE_FILE, "w") as fp:
        json.dump(state, fp)


def sample_prompt_template(segment: str | None = None) -> Dict[str, Any]:
    """Seleciona aleatoriamente um template de RFQ de acordo com a distribuição Beta.

    Se `segment` for fornecido, limita a seleção aos templates desse segmento.
    Retorna o dicionário do template escolhido.
    """
    state = _load_state()
    # Filtra templates conforme o segmento (se especificado)
    candidates = [tpl for tpl in RFQ_TEMPLATES if segment is None or tpl["segment"] == segment]
    if not candidates:
        # Se não houver candidatos, retorna o primeiro template genérico
        return RFQ_TEMPLATES[0]
    best_tpl = None
    best_val = -1.0
    for tpl in candidates:
        params = state.get(tpl["id"], {"alpha": 1.0, "beta": 1.0})
        val = random.betavariate(params["alpha"], params["beta"])
        if val > best_val:
            best_val = val
            best_tpl = tpl
    return best_tpl or candidates[0]


def update_template_result(template_id: str, reward: float) -> None:
    """Atualiza os parâmetros (alpha, beta) de um template conforme a recompensa.

    Se `reward` > 0, é considerado um sucesso e `alpha` é incrementado.
    Caso contrário, incrementa `beta`.
    """
    state = _load_state()
    if template_id not in state:
        state[template_id] = {"alpha": 1.0, "beta": 1.0}
    if reward > 0:
        state[template_id]["alpha"] += 1
    else:
        state[template_id]["beta"] += 1
    _save_state(state)