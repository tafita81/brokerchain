"""Ponto de entrada FastAPI para o Broker de Conformidade Viva.

Este aplicativo expõe diversas rotas REST para ingestão de fornecedores,
geração de RFQs, consulta de catálogos e integração com armazéns. A lógica
principia com a leitura de `providers.yaml` para instanciar conectores.
"""

from __future__ import annotations

import os
import base64
import yaml
from typing import Dict, Any, List

from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

# Adjust Python path so local modules can be imported when running this file
import sys
sys.path.append(os.path.dirname(__file__))

from connectors import get_connector_class  # type: ignore
from connectors.base import BaseConnector  # type: ignore
from bandit import sample_prompt_template, update_template_result  # type: ignore
from prompts import RFQ_TEMPLATES  # type: ignore
from compliance import assess_pfas_epr, assess_buy_america, assess_eudr, next_expiry_date, random_certification_id  # type: ignore

# Importa bibliotecas opcionais. ``httpx`` é utilizado para integrações externas
# (por exemplo, Payoneer) e ``openai`` é usado para geração dinâmica de mensagens
# com ChatGPT. Ambas são importadas de forma opcional para permitir que o
# aplicativo funcione mesmo se não estiverem instaladas.
try:
    import httpx  # type: ignore
except Exception:
    httpx = None  # type: ignore

try:
    import openai  # type: ignore
    _OPENAI_AVAILABLE = True
except Exception:
    _OPENAI_AVAILABLE = False

# Importa bibliotecas para leitura de e-mail via IMAP
import imaplib
import email
import ssl

# Carrega provedores a partir do YAML
# Se a variável de ambiente PROVIDERS_FILE não estiver definida, utiliza o
# arquivo `providers.yaml` localizado no mesmo diretório deste módulo.
DEFAULT_PROVIDERS_PATH = os.path.join(os.path.dirname(__file__), "providers.yaml")
PROVIDERS_FILE = os.getenv("PROVIDERS_FILE", DEFAULT_PROVIDERS_PATH)

# Caminhos padrão para arquivos de associações e fundos de incentivo. Estes YAMLs
# trazem sugestões de grupos/organizações e programas de financiamento que
# podem reforçar a credibilidade e viabilizar recursos para a empresa.
DEFAULT_ASSOCIATIONS_PATH = os.path.join(os.path.dirname(__file__), "associations.yaml")
DEFAULT_FUNDING_PATH = os.path.join(os.path.dirname(__file__), "funding.yaml")
ASSOCIATIONS_FILE = os.getenv("ASSOCIATIONS_FILE", DEFAULT_ASSOCIATIONS_PATH)
FUNDING_FILE = os.getenv("FUNDING_FILE", DEFAULT_FUNDING_PATH)


def load_providers() -> Dict[str, Dict[str, Any]]:
    try:
        with open(PROVIDERS_FILE, "r") as fp:
            return yaml.safe_load(fp)
    except Exception:
        return {}


def load_yaml_file(path: str) -> Dict[str, Any]:
    """Carrega dados de um arquivo YAML retornando dicionário.

    Se o arquivo não existir ou ocorrer erro na leitura, retorna dicionário vazio.

    Args:
        path: caminho para arquivo YAML.

    Returns:
        dicionário com dados.
    """
    try:
        with open(path, "r") as fp:
            return yaml.safe_load(fp) or {}
    except Exception:
        return {}


def load_associations() -> Dict[str, Dict[str, Any]]:
    """Lê lista de associações recomendadas a partir de associations.yaml."""
    return load_yaml_file(ASSOCIATIONS_FILE)


def load_funding() -> Dict[str, Dict[str, Any]]:
    """Lê lista de programas de financiamento a partir de funding.yaml."""
    return load_yaml_file(FUNDING_FILE)


def init_connectors() -> Dict[str, BaseConnector]:
    providers = load_providers()
    instances: Dict[str, BaseConnector] = {}
    for name, cfg in providers.items():
        ctype = cfg.get("type")
        ConnectorClass = get_connector_class(ctype)
        instances[name] = ConnectorClass(cfg.get("config", {}))
    return instances


connectors: Dict[str, BaseConnector] = init_connectors()

# Carrega listas de associações e programas de financiamento em tempo de
# inicialização. Estes dados são utilizados em rotas de informação e para
# incrementar a credibilidade do broker.
ASSOCIATIONS: Dict[str, Dict[str, Any]] = load_associations()
FUNDING_PROGRAMS: Dict[str, Dict[str, Any]] = load_funding()

# Estatísticas simples de operação por frente regulatória. Estas variáveis
# são atualizadas a cada envio de RFQ e negociação, permitindo gerar
# dashboards em tempo real. Cada frente (pfas, buyamerica, eudr, generic)
# mantém contadores de RFQs enviados, RFQs com resposta, negociações e
# negociações bem-sucedidas, além de um campo para registrar comissões.
METRICS: Dict[str, Dict[str, int]] = {
    "pfas": {"rfqs_sent": 0, "rfqs_success": 0, "negotiations": 0, "negotiations_success": 0, "commissions": 0},
    "buyamerica": {"rfqs_sent": 0, "rfqs_success": 0, "negotiations": 0, "negotiations_success": 0, "commissions": 0},
    "eudr": {"rfqs_sent": 0, "rfqs_success": 0, "negotiations": 0, "negotiations_success": 0, "commissions": 0},
    "generic": {"rfqs_sent": 0, "rfqs_success": 0, "negotiations": 0, "negotiations_success": 0, "commissions": 0},
}

# Configuração de templates Jinja2. Os arquivos HTML estão no diretório
# ``templates`` desta aplicação. Use ``TemplateResponse`` para renderizar
# páginas dinâmicas.
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

app = FastAPI(title="BCV – Broker de Conformidade Viva", version="5.0.0")


def get_basic_auth_user(request: Request):
    """Valida autenticação básica simples usando variáveis de ambiente."""
    auth = request.headers.get("Authorization")
    if not auth or not auth.lower().startswith("basic "):
        raise HTTPException(status_code=401, detail="Autenticação necessária")
    encoded = auth.split(" ", 1)[1].strip()
    try:
        decoded = base64.b64decode(encoded).decode()
    except Exception:
        raise HTTPException(status_code=401, detail="Credenciais inválidas")
    username, _, password = decoded.partition(":")
    if (username == os.getenv("BASIC_AUTH_USER") and password == os.getenv("BASIC_AUTH_PASS")):
        return username
    raise HTTPException(status_code=401, detail="Credenciais incorretas")


# --------- Esquemas de entrada ---------
class RFQRequest(BaseModel):
    company: str
    contact_email: str | None = Field(None, description="Destinatário para RFQ")
    sku: str = Field(..., description="Identificador do SKU")
    segment: str | None = Field(None, description="Segmento regulatório: PFAS/EPR, BuyAmerica, EUDR ou Genérico")
    provider: str | None = Field(None, description="Nome do provedor no providers.yaml para envio da RFQ")
    payment_terms: str | None = Field(None, description="Condição de pagamento desejada (ex.: Net30)")
    risk_assumption: str | None = Field(None, description="Responsável por custos de extravio/desistência/danos")


class EUDRTraceRequest(BaseModel):
    lot_id: str
    commodity: str
    farm_polygon: List[List[float]] | None = None
    shipments: List[Dict[str, Any]]

# --------- Esquema de negociação ---------
class NegotiationRequest(BaseModel):
    """Dados necessários para negociar condições de fornecimento.

    Este schema permite ao broker solicitar propostas aos fornecedores com
    termos de pagamento estendidos e transferência de riscos. Os campos
    ``payment_terms`` e ``risk_assumption`` são opcionais: se omitidos,
    serão preenchidos com valores padrão definidos no ``providers.yaml``.
    """
    provider: str = Field(..., description="Nome do provedor conforme providers.yaml")
    sku: str = Field(..., description="Identificador do SKU a negociar")
    company: str = Field(..., description="Nome da empresa compradora")
    quantity: int = Field(..., description="Quantidade desejada para negociação")
    contact_email: str | None = Field(None, description="E‑mail de contato do fornecedor, se aplicável")
    payment_terms: str | None = Field(None, description="Termos de pagamento a propor ao fornecedor")
    risk_assumption: str | None = Field(None, description="Descrição das responsabilidades de risco a propor")
    price: float | None = Field(None, description="Preço alvo (opcional)")


# --------- Rotas ---------

@app.get("/")
def root():
    return {"name": app.title, "version": app.version}


@app.get("/providers")
def list_providers():
    """Retorna a lista de provedores e seus tipos."""
    return {name: getattr(conn, "__class__").__name__ for name, conn in connectors.items()}


@app.get("/suppliers/braskem/products")
def braskem_products(user: str = Depends(get_basic_auth_user)):
    """Retorna catálogo da Braskem com informações de conformidade."""
    braskem = connectors.get("braskem")
    if not braskem:
        raise HTTPException(500, "Conector Braskem não configurado")
    products = braskem.list_products()
    enriched = []
    for prod in products:
        compliance_flags = assess_pfas_epr(prod)
        prod["pfas_free"] = compliance_flags["pfas_free"]
        prod["epr_ready"] = compliance_flags["epr_ready"]
        prod["buy_america_eligible"] = assess_buy_america(prod)
        enriched.append(prod)
    return {"products": enriched}

# Novo endpoint genérico para qualquer fornecedor que implemente list_products().
# Permite acessar catálogos de múltiplos fornecedores, como Braskem ou ChemGreen,
# especificando o nome do conector definido em providers.yaml.
@app.get("/suppliers/{supplier}/products")
def generic_supplier_products(supplier: str, user: str = Depends(get_basic_auth_user)):
    conn = connectors.get(supplier)
    if not conn or not hasattr(conn, "list_products"):
        raise HTTPException(404, f"Fornecedor '{supplier}' não configurado ou sem suporte a listagem de produtos")
    products = conn.list_products()
    enriched = []
    for prod in products:
        # Aplica regras de conformidade se disponíveis
        flags = assess_pfas_epr(prod)
        prod = prod.copy()
        prod["pfas_free"] = flags.get("pfas_free")
        prod["epr_ready"] = flags.get("epr_ready")
        prod["buy_america_eligible"] = assess_buy_america(prod)
        enriched.append(prod)
    return {"supplier": supplier, "products": enriched}


@app.get("/warehouse/list")
def list_warehouses():
    """Lista armazéns configurados com seus metadados."""
    whs = []
    for name, conn in connectors.items():
        if hasattr(conn, "metadata"):
            meta = conn.metadata()
            whs.append({"name": name, **meta})
    return {"warehouses": whs}


@app.get("/warehouse/pull_orders")
def pull_orders(user: str = Depends(get_basic_auth_user)):
    """Agrega pedidos de todos armazéns (stub)."""
    orders = []
    for name, conn in connectors.items():
        if hasattr(conn, "pull_orders"):
            try:
                orders.extend(conn.pull_orders())
            except NotImplementedError:
                continue
    return {"orders": orders}


@app.post("/rfq")
def send_rfq(req: RFQRequest):
    """Cria e envia uma RFQ para um fornecedor via conector selecionado."""
    # Seleciona template pelo segmento
    tpl = sample_prompt_template(req.segment)
    template_str = tpl["template"]
    # Seleciona conector: prioridade email -> http_generic
    connector: BaseConnector | None = None
    if req.provider:
        connector = connectors.get(req.provider)
    else:
        # fallback para email se houver
        connector = connectors.get("email") or connectors.get("http_generic")
    if not connector:
        raise HTTPException(500, "Nenhum conector disponível para envio de RFQ")
    # Monta dict da RFQ
    rfq_payload = req.model_dump()
    # Carrega configurações para preencher termos de pagamento e risco
    providers_cfg = load_providers()
    prov_name = req.provider or ""
    if prov_name and prov_name in providers_cfg:
        cfg = providers_cfg[prov_name].get("config", {})
        if not rfq_payload.get("payment_terms"):
            rfq_payload["payment_terms"] = cfg.get("payment_terms")
        if not rfq_payload.get("risk_assumption"):
            rfq_payload["risk_assumption"] = cfg.get("risk_assumption")
    # Envia RFQ
    result = connector.send_rfq(rfq_payload, template_str)
    # Atualiza contadores de métricas por frente
    seg_raw = (req.segment or "generic").lower()
    if "pfas" in seg_raw or "epr" in seg_raw:
        mkey = "pfas"
    elif "buy" in seg_raw and "amer" in seg_raw:
        mkey = "buyamerica"
    elif "eudr" in seg_raw:
        mkey = "eudr"
    else:
        mkey = "generic"
    METRICS[mkey]["rfqs_sent"] += 1
    if result.get("ok"):
        METRICS[mkey]["rfqs_success"] += 1
    # Atualiza bandit (supõe sucesso se ok=True)
    update_template_result(tpl["id"], 1.0 if result.get("ok") else 0.0)
    # Utiliza IA para refinar o template para futuras RFQs
    try:
        _maybe_refine_prompt(req, tpl["id"], template_str, result)
    except Exception:
        pass
    return {"template_id": tpl["id"], "template": template_str, "send_result": result}


# Importa reportlab apenas quando disponível. Quando não instalado (por exemplo, em ambientes
# restritos sem acesso a internet), a geração de PDFs será desativada e orientada pelo
# endpoint a instalar a dependência. O código tenta importar de forma tardia dentro da
# função e, se não conseguir, lança exceção amigável.
try:
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    _REPORTLAB_AVAILABLE = True
except Exception:
    _REPORTLAB_AVAILABLE = False


@app.post("/eudr/trace")
def eudr_trace(req: EUDRTraceRequest, user: str = Depends(get_basic_auth_user)):
    """Gera um passaporte digital (PDF) para um lote conforme EUDR."""
    if not _REPORTLAB_AVAILABLE:
        raise HTTPException(status_code=500, detail="Biblioteca reportlab não está instalada. Instale reportlab para gerar PDF.")
    # Cria diretório de saídas
    out_dir = "dpp"
    os.makedirs(out_dir, exist_ok=True)
    filename = f"{req.lot_id}.pdf"
    filepath = os.path.join(out_dir, filename)
    # Gera PDF
    doc = SimpleDocTemplate(filepath, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []
    elements.append(Paragraph(f"Passaporte Digital – Lote {req.lot_id}", styles["Title"]))
    elements.append(Spacer(1, 12))
    # Tabela com informações
    data = [
        ["Lote", req.lot_id],
        ["Commodity", req.commodity],
        ["Data de geração", str(os.environ.get("GEN_DATE", ""))],
        ["Número de remessas", str(len(req.shipments))],
    ]
    table = Table(data, colWidths=[120, 300])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 12))
    # Adiciona shipments
    for i, sh in enumerate(req.shipments, start=1):
        elements.append(Paragraph(f"Remessa {i}: {sh}", styles["Normal"]))
        elements.append(Spacer(1, 4))
    # Renderiza PDF
    doc.build(elements)
    return {"ok": True, "pdf_path": filepath}


@app.get("/eudr/dpp/{lot_id}")
def get_dpp(lot_id: str, user: str = Depends(get_basic_auth_user)):
    filepath = os.path.join("dpp", f"{lot_id}.pdf")
    if not os.path.exists(filepath):
        raise HTTPException(404, "DPP não encontrado")
    return FileResponse(filepath, media_type="application/pdf", filename=f"{lot_id}.pdf")


# --------------------------------------------------------------
# Funcionalidades adicionais
# --------------------------------------------------------------

@app.get("/logistics/route")
def logistics_route(origin_country: str, dest_country: str) -> Dict[str, Any]:
    """Sugere uma rota logística via hubs configurados.

    Para simplificar, se o destino é os EUA ("US"), o pedido será roteado
    através do armazém ``logisticsplus_us``; caso contrário, será roteado
    via ``logisticsplus_sp``. Essa lógica garante que todos os produtos
    passem por um hub para inspeção e cross‑docking antes da entrega final.

    Args:
        origin_country: código do país de origem (ISO alpha‑2).
        dest_country: código do país de destino (ISO alpha‑2).

    Returns:
        dict: rota sugerida e hub selecionado.
    """
    hub = "logisticsplus_us" if dest_country.upper() == "US" else "logisticsplus_sp"
    path = [origin_country.upper(), hub, dest_country.upper()]
    return {"route": path, "hub": hub}


def _maybe_refine_prompt(req: RFQRequest, template_id: str, template: str, result: Dict[str, Any]) -> None:
    """Utiliza o ChatGPT para sugerir ajustes em templates de RFQ.

    Quando ``OPENAI_API_KEY`` estiver definido e a biblioteca ``openai``
    estiver disponível, esta função envia contexto sobre o segmento, SKU e
    resultado do envio (sucesso ou falha) para o ChatGPT e registra uma
    sugestão de melhoria no console. Não interrompe o fluxo em caso de
    falha na chamada de API.

    Args:
        req: requisição de RFQ original.
        template_id: identificador do template utilizado.
        template: conteúdo do template usado.
        result: retorno do conector.
    """
    if not _OPENAI_AVAILABLE:
        return
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return
    openai.api_key = api_key  # type: ignore
    messages = [
        {
            "role": "system",
            "content": (
                "Você é um especialista em otimização de prompts para RFQs. Dada a"
                " descrição de um template e o resultado do envio (sucesso ou falha),"
                " sugira mudanças concisas para aumentar a taxa de resposta dos"
                " fornecedores, mantendo conformidade regulatória."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Segmento: {req.segment or 'Genérico'}\n"
                f"SKU: {req.sku}\n"
                f"Template (ID {template_id}):\n{template}\n"
                f"Resultado: {'sucesso' if result.get('ok') else 'falha'}\n"
                "Sugira ajustes."
            ),
        },
    ]
    try:
        response = openai.ChatCompletion.create(  # type: ignore
            model=os.getenv("OPENAI_MODEL", "gpt-4o"),
            messages=messages,
            temperature=0.5,
        )
        suggestion = response["choices"][0]["message"]["content"].strip()
        print(f"Sugestão de melhoria para o template {template_id}: {suggestion}")
    except Exception as exc:
        print(f"Erro ao refinar template via ChatGPT: {exc}")


def payoneer_payout(amount_cents: int, currency: str = "USD", description: str = "", metadata: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Envia uma solicitação de pagamento ao Payoneer.

    Esta função é um exemplo de integração com o Payoneer para repassar
    comissões ou recebimentos ao broker. Os valores são expressos em
    centavos para evitar problemas de precisão. O URL da API, a chave e o
    identificador da conta são obtidos de variáveis de ambiente. Caso
    ``httpx`` não esteja disponível ou as credenciais estejam ausentes, a
    função retorna uma mensagem informativa. Em ambientes sem acesso à
    Internet, esta função serve apenas como demonstração.

    Args:
        amount_cents: valor em centavos (por exemplo, 1000 = US$10.00).
        currency: código de moeda (USD, EUR, BRL).
        description: descrição da transação.
        metadata: dicionário adicional enviado no corpo da requisição.

    Returns:
        dict: resultado da chamada (simulada) ao Payoneer.
    """
    if httpx is None:
        return {"ok": False, "reason": "httpx_unavailable"}
    api_key = os.getenv("PAYONEER_API_KEY")
    account_id = os.getenv("PAYONEER_ACCOUNT_ID")
    payout_url = os.getenv("PAYONEER_PAYOUT_URL")
    if not (api_key and account_id and payout_url):
        return {"ok": False, "reason": "missing_payoneer_credentials"}
    metadata = metadata or {}
    payload = {
        "payee_id": account_id,
        "amount": amount_cents / 100.0,
        "currency": currency.upper(),
        "description": description,
        "metadata": metadata,
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    try:
        with httpx.Client(timeout=15) as client:  # type: ignore
            resp = client.post(payout_url, json=payload, headers=headers)
            resp.raise_for_status()
            return {"ok": True, "response": resp.json()}
    except Exception as exc:
        return {"ok": False, "reason": str(exc)}


# -------------------------------------------------------------------------
# Leitura de mensagens via IMAP
# -------------------------------------------------------------------------

def fetch_inbox(limit: int = 10) -> List[Dict[str, str]]:
    """Busca as mensagens mais recentes da caixa de entrada via IMAP.

    Esta função acessa o servidor IMAP definido em variáveis de ambiente
    (``IMAP_HOST``, ``IMAP_USER``, ``IMAP_PASS``) e retorna as mensagens
    mais recentes, contendo remetente, assunto e data. Caso as
    credenciais não estejam configuradas ou ocorra algum erro, retorna
    uma lista vazia.

    Args:
        limit: número máximo de mensagens a retornar.

    Returns:
        Lista de dicionários com campos ``from``, ``subject`` e ``date``.
    """
    host = os.getenv("IMAP_HOST")
    user = os.getenv("IMAP_USER")
    password = os.getenv("IMAP_PASS")
    if not (host and user and password):
        return []
    try:
        context = ssl.create_default_context()
        with imaplib.IMAP4_SSL(host, 993, ssl_context=context) as imap:
            imap.login(user, password)
            imap.select("INBOX")
            typ, data = imap.search(None, "ALL")
            msg_ids = data[0].split()
            mails: List[Dict[str, str]] = []
            for msg_id in msg_ids[-limit:]:
                typ, msg_data = imap.fetch(msg_id, "(RFC822)")
                for response in msg_data:
                    if isinstance(response, tuple):
                        msg = email.message_from_bytes(response[1])
                        # Extrai campos comuns
                        subject = str(email.header.make_header(email.header.decode_header(msg.get("Subject", ""))))
                        sender = str(email.header.make_header(email.header.decode_header(msg.get("From", ""))))
                        date = msg.get("Date", "")
                        mails.append({"from": sender, "subject": subject, "date": date})
            return list(reversed(mails))
    except Exception:
        return []


# -------------------------------------------------------------------------
# Endpoints de páginas estáticas e métricas
# -------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def landing_page(request: Request):
    """Exibe a landing page principal com informações gerais."""
    return templates.TemplateResponse("landing.html", {"request": request})


@app.get("/pfas", response_class=HTMLResponse)
def pfas_page(request: Request):
    """Página dedicada à frente PFAS/EPR."""
    return templates.TemplateResponse("pfas.html", {"request": request})


@app.get("/buyamerica", response_class=HTMLResponse)
def buyamerica_page(request: Request):
    """Página dedicada à frente Buy America."""
    return templates.TemplateResponse("buyamerica.html", {"request": request})


@app.get("/eudr", response_class=HTMLResponse)
def eudr_page(request: Request):
    """Página dedicada à frente EUDR."""
    return templates.TemplateResponse("eudr.html", {"request": request})


@app.get("/metrics/{front}", response_class=HTMLResponse)
def metrics_page(front: str, request: Request):
    """Renderiza a página de métricas para uma frente específica.

    Args:
        front: identificador da frente (pfas, buyamerica, eudr ou generic).
        request: objeto de requisição (necessário para TemplateResponse).

    Returns:
        Página HTML com dados de métricas.
    """
    key = front.lower()
    data = METRICS.get(key)
    if data is None:
        raise HTTPException(status_code=404, detail="Frente desconhecida")
    return templates.TemplateResponse("metrics.html", {"request": request, "front": key, "metrics": data})


@app.get("/messages/inbox", response_class=JSONResponse)
def inbox(limit: int = 10, user: str = Depends(get_basic_auth_user)):
    """Retorna as últimas mensagens de e-mail da caixa de entrada.

    As mensagens são lidas via IMAP usando as variáveis de ambiente
    ``IMAP_HOST``, ``IMAP_USER`` e ``IMAP_PASS``.
    """
    return {"messages": fetch_inbox(limit)}


# Endpoint para retornar métricas em formato JSON para todas as frentes
@app.get("/metrics", response_class=JSONResponse)
def metrics_json(user: str = Depends(get_basic_auth_user)) -> Dict[str, Any]:
    """Retorna todas as métricas agregadas para cada frente em formato JSON."""
    return METRICS


# -------------------------------------------------------------------------
# Associações e programas de financiamento
# -------------------------------------------------------------------------

@app.get("/api/associations", response_class=JSONResponse)
def associations_json() -> Dict[str, Any]:
    """Retorna as associações recomendadas em formato JSON.

    Estes grupos e organizações podem ser buscados pelo broker para
    certificações, networking e benefícios regulatórios.
    """
    return ASSOCIATIONS


@app.get("/api/funding", response_class=JSONResponse)
def funding_json() -> Dict[str, Any]:
    """Retorna programas de financiamento/incentivo em formato JSON.

    Estes programas incluem grants e iniciativas que ajudam pequenas
    empresas a desenvolver tecnologias ambientais e crescer sem capital
    próprio.
    """
    return FUNDING_PROGRAMS


@app.get("/associations", response_class=HTMLResponse)
def associations_page(request: Request):
    """Renderiza página HTML com lista de associações e benefícios.

    A página exibe as principais organizações (ex.: Sustainable Packaging
    Coalition, GS1 US) com seus benefícios e links para inscrição.
    """
    return templates.TemplateResponse(
        "associations.html",
        {"request": request, "associations": ASSOCIATIONS},
    )


@app.get("/funding", response_class=HTMLResponse)
def funding_page(request: Request):
    """Renderiza página HTML com lista de programas de financiamento.

    Cada programa inclui nome, descrição, critérios de elegibilidade e link
    para candidatura. Use esta página para consultar oportunidades de grants
    e incentivos sem diluir participação.
    """
    return templates.TemplateResponse(
        "funding.html",
        {"request": request, "funding": FUNDING_PROGRAMS},
    )

# Nova página de plano estratégico
@app.get("/strategy", response_class=HTMLResponse)
def strategy_page(request: Request):
    """Renderiza página HTML com o plano estratégico.

    Esta página resume, em ordem lógica, as etapas para obtenção de
    credenciamento, inscrição em associações, busca de financiamentos e
    preparação de infraestrutura antes de iniciar a negociação de RFQs.

    Returns:
        TemplateResponse: página HTML com conteúdo estático.
    """
    return templates.TemplateResponse(
        "strategy.html",
        {"request": request},
    )


# Função auxiliar para geração de mensagens de negociação
def _craft_negotiation_message(req: NegotiationRequest, payment_terms: str, risk_assumption: str) -> str:
    """Gera texto de negociação com base em IA ou fallback.

    Ao negociar com fornecedores, o broker sempre busca estender os
    prazos de pagamento (para operar sem capital próprio) e transferir
    a responsabilidade por extravio, devolução ou danos. Se a
    biblioteca ``openai`` estiver disponível e configurada, usa o
    ChatGPT para redigir a mensagem; caso contrário, aplica um modelo
    fixo com placeholders.

    Args:
        req: solicitação de negociação contendo SKU, quantidade, etc.
        payment_terms: termos de pagamento propostos.
        risk_assumption: cláusula de responsabilidade proposta.

    Returns:
        Mensagem em português dirigida ao fornecedor.
    """
    # IA: tenta redigir via ChatGPT
    if _OPENAI_AVAILABLE and os.getenv("OPENAI_API_KEY"):
        openai.api_key = os.getenv("OPENAI_API_KEY")  # type: ignore
        messages = [
            {
                "role": "system",
                "content": (
                    "Você é um especialista em negociação B2B para supply chain."
                    " Sua missão é redigir e‑mails curtos e persuasivos em português"
                    " que proponham termos de pagamento estendidos e transferência de"
                    " riscos (extravio, desistência, produtos danificados) ao fornecedor."
                    " O objetivo é que o broker não precise investir capital próprio."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Fornecedor: {req.provider}\n"
                    f"SKU: {req.sku}\n"
                    f"Quantidade: {req.quantity}\n"
                    f"Comprador: {req.company}\n"
                    f"Termos de pagamento: {payment_terms}\n"
                    f"Cláusula de responsabilidade: {risk_assumption}\n"
                    "Escreva a mensagem para o fornecedor."
                ),
            },
        ]
        try:
            response = openai.ChatCompletion.create(  # type: ignore
                model=os.getenv("OPENAI_MODEL", "gpt-4o"),
                messages=messages,
                temperature=0.5,
            )
            return response["choices"][0]["message"]["content"].strip()
        except Exception as exc:
            print(f"Erro ao gerar mensagem de negociação via ChatGPT: {exc}")
    # Fallback estático
    return (
        f"Olá,\n\n"
        f"Somos um broker B2B sediado nos EUA/Brasil e estamos interessados em negociar o SKU {req.sku}"
        f" para a empresa {req.company}. Pretendemos adquirir {req.quantity} unidades.\n"
        f"Proposta de pagamento: {payment_terms}, com pagamento somente após a entrega e inspeção em nosso armazém.\n"
        f"Proposta de responsabilidade: {risk_assumption}.\n"
        f"Solicitamos que informe preço (CIF/FOB), prazo de entrega e confirme se concorda com as condições.\n"
        f"Os itens devem ser enviados ao nosso hub logístico para cross‑docking e inspeção antes da remessa final ao comprador.\n\n"
        f"Aguardamos seu retorno.\n\n"
        f"Atenciosamente,\n"
        f"Equipe de Sourcing"
    )


@app.post("/negotiate")
def negotiate(req: NegotiationRequest):
    """Propõe condições de pagamento e risco a um fornecedor.

    Obtém valores padrão de pagamento e risco a partir de ``providers.yaml``
    caso não sejam informados na requisição. Em seguida gera uma mensagem
    de negociação (usando IA se disponível) e a envia via conector
    correspondente. A resposta indica sucesso ou falha do envio e exibe
    a mensagem enviada.

    Args:
        req: dados da negociação.

    Returns:
        dict: dados do envio e da mensagem.
    """
    providers_cfg = load_providers()
    cfg = providers_cfg.get(req.provider, {}).get("config", {})
    # Para provedores como "email" ou outros canais genéricos, a configuração pode
    # estar vazia. Nesses casos, seguimos com valores padrão de pagamento e risco.
    # Preenche termos padrão se não especificados
    payment_terms = req.payment_terms or cfg.get("payment_terms") or "Net45"
    risk_assumption = req.risk_assumption or cfg.get("risk_assumption") or "Fornecedor assume riscos"
    # Gera mensagem de negociação
    message = _craft_negotiation_message(req, payment_terms, risk_assumption)
    # Prepara payload para envio
    rfq_payload: Dict[str, Any] = {
        "sku": req.sku,
        "company": req.company,
        "quantity": req.quantity,
        "contact_email": req.contact_email,
        "payment_terms": payment_terms,
        "risk_assumption": risk_assumption,
        "subject": f"Negociação do SKU {req.sku}",
        "negotiation": True,
    }
    connector = connectors.get(req.provider)
    if not connector or not hasattr(connector, "send_rfq"):
        raise HTTPException(500, f"Fornecedor '{req.provider}' não possui conector configurado para envio")
    result = connector.send_rfq(rfq_payload, message)
    # Atualiza métricas de negociação
    seg_raw = (req.payment_terms or "generic").lower()  # segmento não está no schema; usamos generic
    # Tenta inferir frente pelo SKU ou provedor
    mkey = "generic"
    # heurística: se provedor faz parte de PFAS/EPR
    if req.provider:
        name_lower = req.provider.lower()
        if "bio" in name_lower or "veg" in name_lower or "sun" in name_lower or "sabe" in name_lower:
            mkey = "pfas"
        elif "dyson" in name_lower or "prestige" in name_lower:
            mkey = "buyamerica"
        elif "sancoffee" in name_lower or "suzano" in name_lower or "klabin" in name_lower:
            mkey = "eudr"
    METRICS[mkey]["negotiations"] += 1
    if result.get("ok"):
        METRICS[mkey]["negotiations_success"] += 1
    return {
        "ok": result.get("ok"),
        "message": message,
        "send_result": result,
    }