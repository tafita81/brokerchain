"""Regras de conformidade para PFAS/EPR, Buy America e EUDR.

Este módulo fornece funções utilitárias para determinar se um produto ou
fornecedor atende às diferentes exigências regulatórias. As regras são
simplificadas e devem ser ajustadas conforme documentação oficial.
"""

from __future__ import annotations

import datetime
import random
from typing import Dict, Any


def assess_pfas_epr(product: Dict[str, Any]) -> Dict[str, Any]:
    """Retorna flags de conformidade PFAS/EPR para um produto.

    Critérios simples:
    * Se o campo `bio_based` for verdadeiro ou o nome contiver "bio", marca
      como PFAS‑free.
    * Se o produto for mono‑material (campo `mono_material`) ou vier de
      fornecedor com certificação EPR (campo `epr_certified`), marca como EPR‑ready.
    """
    result = {}
    name = str(product.get("name", "")).lower()
    # Considera explicitamente o campo pfas_free, caso já esteja informado no produto.
    # Caso não exista, assume que produtos bio-based ou cujo nome contenha "bio"
    # são livres de PFAS por não utilizarem fluorquímicos.  Também considera
    # embalagens de fibra ou papel sem aditivos fluorados.
    result["pfas_free"] = bool(product.get("pfas_free")) or bool(product.get("bio_based")) or ("bio" in name) or ("fibra" in name)
    # Para EPR, verifica se o campo epr_ready ou epr_certified está presente,
    # ou se o produto é mono-material (facilmente reciclável).  Embalagens
    # compostáveis também são tratadas como prontas para EPR.
    result["epr_ready"] = bool(product.get("epr_ready")) or bool(product.get("epr_certified")) or bool(product.get("mono_material")) or bool(product.get("compostavel"))
    return result


def assess_buy_america(product: Dict[str, Any]) -> bool:
    """Determina se um produto é elegível ao programa Buy America.

    Critério simplificado: país de origem deve ser EUA (US) ou, se o produto
    tiver montagem final nos EUA (campo `final_assembly_us`), também é elegível.
    """
    return product.get("country") == "US" or bool(product.get("final_assembly_us"))


def assess_eudr(product: Dict[str, Any], farm_geo: Dict[str, Any] | None = None) -> bool:
    """Determina se um produto atende aos requisitos básicos da EUDR.

    Para este exemplo, exige que haja `geo_coordinates` ou `farm_geo` e que o
    produto seja de um país reconhecido (BR, EC, CO, etc.). Uma verificação
    séria deve consultar bancos de dados oficiais.
    """
    # Se houver geocoordenadas fornecidas via farm_geo ou no produto, ou se o
    # produto for explicitamente marcado como eudr_certified, é considerado
    # elegível.  A lista de países é mantida para referência, mas produtos
    # marcados como eudr_certified são aceitos independentemente do país.
    if product.get("eudr_certified"):
        return True
    if farm_geo or product.get("geo_coordinates"):
        country = product.get("country")
        return country in {"BR", "CO", "EC", "PE", "VN", "NG"}
    return False


def next_expiry_date(days: int = 365) -> str:
    """Gera uma data ISO para expiração futura (ex.: certificado)."""
    return (datetime.datetime.utcnow() + datetime.timedelta(days=days)).date().isoformat()


def random_certification_id(prefix: str = "CERT") -> str:
    """Gera um identificador pseudo‑aleatório para certificados de conformidade."""
    return f"{prefix}-{random.randint(100000, 999999)}"

# -----------------------------------------------------------------------------
# Versões aprimoradas das funções de avaliação de conformidade
#
# As definições acima de `assess_pfas_epr`, `assess_buy_america` e `assess_eudr`
# fornecem verificações simplificadas. Para tornar o BCV mais preciso e refletir
# as descobertas recentes (por exemplo, lista de fornecedores PFAS‑free,
# requisitos de Buy America e EUDR), reimplementamos essas funções abaixo.
# Em Python, uma nova definição com o mesmo nome substitui a anterior. Assim,
# as funções abaixo serão utilizadas ao importar o módulo.

def assess_pfas_epr(product: Dict[str, Any]) -> Dict[str, Any]:
    """Avalia se um produto está em conformidade com requisitos de embalagens livres de PFAS
    e pronto para EPR.

    Esta versão considera campos booleanos (`pfas_free`, `bio_based`, `compostavel`,
    `epr_ready`, `epr_certified`) fornecidos pelo catálogo do fornecedor. Ela
    também infere a ausência de PFAS a partir de palavras‑chave no nome e
    descrição (bagasse, bagaço, fibra, cornstarch, bio, etc.). Produtos feitos
    de fibras vegetais ou compostáveis são tratados como PFAS‑free, refletindo
    práticas de fabricantes como Bioleader e Vegware【732713063189336†L40-L83】【246364944531829†L27-L57】.

    Para EPR, considera‑se pronto se o item for mono‑material, compostável ou
    explicitamente marcado como `epr_ready` ou `epr_certified`.

    Args:
        product: dicionário com atributos do produto.

    Returns:
        Dict[str, Any]: flags `pfas_free` e `epr_ready`.
    """
    name = str(product.get("name", "")).lower()
    desc = str(product.get("description", "")).lower()
    # Inicializa com campos explícitos
    pfas_flag = bool(product.get("pfas_free"))
    epr_flag = bool(product.get("epr_ready")) or bool(product.get("epr_certified"))
    # Considera bio‑based e compostável como PFAS‑free
    pfas_flag = pfas_flag or bool(product.get("bio_based")) or bool(product.get("compostavel"))
    # Palavras‑chave que sugerem fibras naturais ou materiais renováveis
    keywords = [
        "bagasse",
        "bagaço",
        "fibra",
        "fiber",
        "cornstarch",
        "amido",
        "bio",
        "biopolímero",
        "molded fibre",
    ]
    if not pfas_flag:
        for kw in keywords:
            if kw in name or kw in desc:
                pfas_flag = True
                break
    # Critérios para prontidão EPR
    epr_flag = epr_flag or bool(product.get("mono_material")) or bool(product.get("compostavel"))
    if not epr_flag:
        if any(substr in desc for substr in ["compost", "compostável", "compostavel", "reciclável", "recyclable"]):
            epr_flag = True
    return {"pfas_free": pfas_flag, "epr_ready": epr_flag}


def assess_buy_america(product: Dict[str, Any]) -> bool:
    """Determina se um produto atende aos requisitos do programa Buy America.

    O Buy America, que se aplica a projetos financiados por agências como DOT,
    FTA e FHWA, exige que produtos sejam produzidos nos EUA ou tenham seu valor
    agregado majoritariamente no país. Consideramos um item elegível quando:

      * O campo `country` é "US";
      * A montagem final ocorre nos EUA (`final_assembly_us`);
      * Há marcações explícitas de fabricação/fundição nos EUA (campos
        `manufactured_in_us` ou `melted_and_manufactured_us`)【262551720232303†L65-L110】.

    Args:
        product: dicionário de atributos do produto.

    Returns:
        bool: True se o produto atende ao Buy America, False caso contrário.
    """
    country = product.get("country")
    return (
        country == "US"
        or bool(product.get("final_assembly_us"))
        or bool(product.get("manufactured_in_us"))
        or bool(product.get("melted_and_manufactured_us"))
    )


def assess_eudr(product: Dict[str, Any], farm_geo: Dict[str, Any] | None = None) -> bool:
    """Verifica se um produto está em conformidade com a EUDR (Regulamento de produtos livres de desmatamento).

    A EUDR proíbe importação de produtos de commodities (café, cacau, madeira, borracha,
    soja, carne bovina, óleo de palma, etc.) provenientes de áreas desmatadas após 31/12/2020.
    Para cumprir, operadores devem demonstrar rastreabilidade geográfica【537191952811551†L464-L577】.

    Este verificador considera um produto EUDR‑ready quando:

      * O campo `eudr_certified` é True; ou
      * Há coordenadas geográficas (`geo_coordinates`) no produto ou fornecidas
        via `farm_geo`, e o país de origem está em uma lista de países
        exportadores abrangidos (Brasil, Colômbia, Equador, Peru, Vietnã, Nigéria);
      * Sem coordenadas, não cumpre o requisito de rastreabilidade.

    Args:
        product: dicionário de atributos do produto.
        farm_geo: coordenadas fornecidas no momento da consulta (opcional).

    Returns:
        bool: True se atende à EUDR, False caso contrário.
    """
    if bool(product.get("eudr_certified")):
        return True
    coordinates_present = farm_geo is not None or product.get("geo_coordinates") is not None
    if not coordinates_present:
        return False
    country = product.get("country")
    allowed_countries = {"BR", "CO", "EC", "PE", "VN", "NG"}
    return country in allowed_countries