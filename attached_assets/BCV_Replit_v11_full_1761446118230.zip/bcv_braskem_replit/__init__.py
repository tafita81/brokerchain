"""
Package initializer for the BCV (Broker de Conformidade Viva) project.

Adding this empty __init__.py file allows Python to treat the
bcv_braskem_replit directory as a package. Without it, relative imports
between modules like `connectors` and `bandit` would fail when running
`main.py` directly via uvicorn in a Replit environment.
"""

__all__ = []