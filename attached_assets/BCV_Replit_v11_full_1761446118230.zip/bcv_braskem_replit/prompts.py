"""Coleção de prompts e templates usados pelo Broker de Conformidade Viva.

Este módulo contém templates de RFQ que serão escolhidos dinamicamente via
Thompson Sampling. As mensagens são concisas e adaptadas aos
requisitos de conformidade (PFAS/EPR, Buy America, EUDR). Sinta‑se à vontade
para adicionar novos templates e ajustar os existentes.
"""

import typing as _t

# Templates de RFQ (requisitar cotações)
RFQ_TEMPLATES: _t.List[dict] = [
    {
        "id": "pfas_basic",
        "segment": "PFAS/EPR",
        "template": (
            "Olá, tudo bem?\n"
            "Estamos em busca de embalagens isentas de PFAS e prontas para EPR.\n"
            "Poderia nos informar preço (CIF), MOQ e prazo de entrega para o SKU {sku}?\n"
            "Favor incluir informações sobre certificações e declaração de conformidade."
        ),
    },
    {
        "id": "packaging_bio",
        "segment": "PFAS/EPR",
        "template": (
            "Olá,\n"
            "Estamos buscando embalagens compostáveis e sem PFAS para nossos produtos. "
            "Favor enviar cotação (CIF), quantidades mínimas e informações sobre certificações de "
            "compostabilidade, biobased e EPR para o SKU {sku}."
        ),
    },
    {
        "id": "buy_america_fastener",
        "segment": "BuyAmerica",
        "template": (
            "Prezados,\n"
            "Solicitamos cotação de parafusos/arruelas produzidos integralmente nos EUA com certificações MIL/ASTM. "
            "Favor incluir preço, lead time e comprovação 'Melted and Manufactured in USA' para o SKU {sku}."
        ),
    },
    {
        "id": "eudr_general",
        "segment": "EUDR",
        "template": (
            "Olá,\n"
            "Para atender às exigências da EUDR, precisamos de produtos com documentação de rastreabilidade e georreferenciamento. "
            "Favor enviar preço, certificações e detalhes de origem para o SKU {sku}."
        ),
    },
    {
        "id": "supplier_general",
        "segment": "Genérico",
        "template": (
            "Olá,\n"
            "Estamos avaliando fornecedores para o SKU {sku}. "
            "Favor informar preço, MOQ, prazo de entrega e quaisquer certificações (PFAS‑free, EPR‑ready, Buy America, EUDR‑ready) disponíveis."
        ),
    },
    {
        "id": "buy_america",
        "segment": "BuyAmerica",
        "template": (
            "Prezados,\n"
            "Estamos cotando itens elegíveis ao Buy America para um projeto com verba federal.\n"
            "Precisamos de preço FOB, lead time e certificados de origem para o produto {sku}.\n"
            "Também informar se há montagem final nos EUA. Obrigado."
        ),
    },
    {
        "id": "eudr_coffee",
        "segment": "EUDR",
        "template": (
            "Olá,\n"
            "Para atender às exigências da EUDR, precisamos de café com rastreabilidade completa.\n"
            "Favor enviar preço, MOQ, documentação de georreferenciamento e certificações para o lote {sku}."
        ),
    },
    {
        "id": "generic_short",
        "segment": "Genérico",
        "template": (
            "Olá,\n"
            "Estamos avaliando fornecedores para o SKU {sku}. Poderia informar preço, MOQ e prazo de entrega?\n"
            "Caso exista documentação relevante (PFAS/EPR/EUDR), favor anexar."
        ),
    },

    # Templates adicionais para linhas específicas de produtos e segmentos
    {
        "id": "pfas_packaging_bio",
        "segment": "PFAS/EPR",
        "template": (
            "Olá, tudo bem?\n"
            "Estamos buscando embalagens de fibra vegetal (bagasse, amido, bio‑PE) totalmente livres de PFAS e prontas para EPR.\n"
            "Gostaríamos de receber cotação CIF, MOQ e prazo de entrega para o item {sku}, juntamente com laudos de compostabilidade e certificações.\n"
            "Também informe se o produto possui certificações OK Compost, EN13432 ou equivalentes."
        ),
    },
    {
        "id": "pfas_packaging_vegware",
        "segment": "PFAS/EPR",
        "template": (
            "Saudações,\n"
            "Precisamos de embalagens compostáveis sem PFAS para uso em serviços de alimentação.\n"
            "Favor cotar o SKU {sku} e enviar preço, MOQ, prazo de entrega e provas de que o produto é apto para compostagem doméstica e industrial.\n"
            "Inclua certificados BPI, OK Compost e declaração de PFAS‑free."
        ),
    },
    {
        "id": "buy_america_fastener",
        "segment": "BuyAmerica",
        "template": (
            "Prezados,\n"
            "Estamos cotando fixadores (parafusos, arruelas) que atendam aos critérios de \"melted and manufactured in the USA\" para um projeto financiado com recursos federais.\n"
            "Por favor, informe preço FOB, lead time, certificações (IATF 16949/ISO 9001) e se o produto {sku} possui rastreabilidade total.\n"
            "Também confirme se a montagem final é nos EUA e inclua certificados de origem."
        ),
    },
    {
        "id": "eudr_general",
        "segment": "EUDR",
        "template": (
            "Olá,\n"
            "Para cumprir a Regulamentação Europeia de Produtos Livres de Desmatamento (EUDR), precisamos de commodities (café, cacau, madeira, celulose, borracha) com rastreabilidade completa.\n"
            "Favor cotar o lote {sku}, indicando preço, peso, georreferenciamento (coordenadas), certificações e documentação de que não houve desmatamento após 31/12/2020.\n"
            "Agradecemos também anexar os passaportes digitais (DPP) ou relatórios equivalentes."
        ),
    },
]

# Prompt base para geração de passaporte digital (DPP) EUDR
DPP_PROMPT = (
    "Você é um sistema de rastreabilidade para a EUDR. Dado um lote de commodities, "
    "gere um passaporte digital em formato PDF contendo: identificação do lote, data de "
    "embarque, peso, coordenadas geográficas do campo de origem, e qualquer certificação disponível. "
    "O PDF deve ser conciso, usando tabelas simples e texto em português."
)