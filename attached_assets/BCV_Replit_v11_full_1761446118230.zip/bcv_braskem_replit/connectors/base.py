"""Classe base para conectores externos.

Cada conector deve herdar de `BaseConnector` e implementar, pelo menos,
`pull_orders()` (caso forneça pedidos) ou `send_rfq()` (caso envie RFQs).
"""

from __future__ import annotations

from typing import List, Dict, Any


class BaseConnector:
    """Interface de alto nível para conectores de fornecedores, armazéns ou APIs.

    Conectores não precisam implementar ambos os métodos: apenas aqueles que
    fizerem sentido para o serviço em questão.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    def pull_orders(self) -> List[Dict[str, Any]]:
        """Retorna uma lista de pedidos (orders) do serviço.

        Deve ser sobrescrito por conectores que suportam essa operação.
        """
        raise NotImplementedError("Conector não implementa pull_orders()")

    def send_rfq(self, rfq: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Envia uma RFQ utilizando o template fornecido.

        Deve ser sobrescrito por conectores capazes de enviar RFQs.
        """
        raise NotImplementedError("Conector não implementa send_rfq()")