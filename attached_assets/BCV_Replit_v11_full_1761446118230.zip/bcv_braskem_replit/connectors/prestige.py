"""Conector de catálogo para Prestige Stamping (Estados Unidos).

Prestige Stamping produz arruelas e fixadores com o selo "melted and
manufactured in the USA", atendendo os critérios do Buy America. A
empresa possui certificações IATF 16949 e ISO 9001【262551720232303†L65-L110】【262551720232303†L116-L123】.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from .base import BaseConnector


DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "prestige_products.json")


class PrestigeConnector(BaseConnector):
    """Lê o catálogo da Prestige Stamping a partir de um arquivo JSON."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []
