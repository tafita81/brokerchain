"""Conector para armazéns, com suporte a múltiplas localizações.

Os armazéns são definidos no arquivo `providers.yaml` com seus metadados.
Este conector implementa uma interface simples para listar armazéns e
recuperar pedidos (stub), permitindo expansão futura para APIs oficiais.
"""

from __future__ import annotations

from typing import Dict, Any, List

from connectors.base import BaseConnector


class WarehouseConnector(BaseConnector):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        # Espera‐se que config contenha 'id', 'address', 'capacity_pallets' etc.
        self.meta = config

    def metadata(self) -> Dict[str, Any]:
        """Retorna os metadados do armazém."""
        return self.meta

    def pull_orders(self) -> List[Dict[str, Any]]:
        """Retorna uma lista de pedidos presentes no armazém.

        Como não temos integração real, retorna lista vazia. Para uso real,
        adaptar para ler de WMS ou planilhas.
        """
        return []