"""Conector de catálogo para a Sabert (Estados Unidos).

A Sabert desenvolve embalagens de polpa natural com diferentes linhas
(Standard Pulp, Pulp Plus™, Pulp Max™) feitas de recursos renováveis
e livres de PFAS. Esses produtos podem ser usados em micro‑ondas e
fornos, com certificações de compostabilidade【148223364329520†L0-L26】【148223364329520†L40-L74】.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from .base import BaseConnector


DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "sabert_products.json")


class SabertConnector(BaseConnector):
    """Lê o catálogo da Sabert a partir de um arquivo JSON."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []
