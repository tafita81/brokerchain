"""Conector para envio de e‑mails via SMTP.

Usa variáveis de ambiente para configuração do servidor SMTP. Envia RFQs
substituindo placeholders no template.
"""

from __future__ import annotations

import os
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from typing import Dict, Any

from connectors.base import BaseConnector


class EmailConnector(BaseConnector):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.smtp_host = os.getenv("SMTP_HOST")
        self.smtp_user = os.getenv("SMTP_USER")
        self.smtp_pass = os.getenv("SMTP_PASS")
        self.from_email = os.getenv("APP_FROM_EMAIL", self.smtp_user)

    def send_rfq(self, rfq: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Envia um e‑mail com a RFQ ou negociação.

        O dicionário ``rfq`` pode conter campos extras como ``payment_terms``,
        ``risk_assumption``, ``quantity``, ``buyer_company`` etc. O ``template``
        deve usar placeholders que correspondam às chaves de ``rfq``.
        """
        to_email = rfq.get("contact_email")
        if not to_email:
            return {"ok": False, "reason": "sem_email_destino"}
        try:
            body = template.format(**rfq)
        except Exception:
            # fallback simples: substitui apenas sku
            body = template.format(sku=rfq.get("sku", ""))
        subject = rfq.get("subject") or f"RFQ para SKU {rfq.get('sku', '')}"
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = Header(subject, "utf-8")
        msg["From"] = self.from_email
        msg["To"] = to_email
        try:
            with smtplib.SMTP(self.smtp_host, 587) as server:
                server.starttls()
                if self.smtp_user and self.smtp_pass:
                    server.login(self.smtp_user, self.smtp_pass)
                server.sendmail(self.from_email, [to_email], msg.as_string())
            return {"ok": True, "channel": "email"}
        except Exception as e:
            return {"ok": False, "reason": str(e)}