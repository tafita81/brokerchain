"""Conector de catálogo para a SunDance (Estados Unidos).

SunDance é uma gráfica e fornecedor de embalagens norte‑americano que
adotou materiais biodegradáveis e compostáveis após legislações de
proibição de PFAS em vários estados. Seus produtos não contêm PFAS
intencionalmente e utilizam substratos orgânicos recicláveis e
compostáveis【265083869860939†L492-L510】.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from .base import BaseConnector


DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "sundance_products.json")


class SundanceConnector(BaseConnector):
    """Lê o catálogo da SunDance a partir de um arquivo JSON."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []
