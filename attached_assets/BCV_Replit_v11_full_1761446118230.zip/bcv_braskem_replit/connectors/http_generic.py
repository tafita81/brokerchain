"""Conector genérico baseado em HTTP para integrações personalizadas.

Este conector utiliza a biblioteca httpx para enviar requisições POST/GET
a serviços externos. A URL e eventuais cabeçalhos são lidos a partir da
configuração em `providers.yaml`. Útil para integrar com marketplaces ou
webhooks customizados.
"""

from __future__ import annotations

import httpx
from typing import Dict, Any, List

from connectors.base import BaseConnector


class HttpGenericConnector(BaseConnector):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.orders_url = config.get("orders_url")
        self.rfq_url = config.get("rfq_url")
        # Endpoint opcional para negociações. Se presente, as solicitações de
        # negociação (flag ``negotiation=True`` no RFQ) serão enviadas para
        # esta URL em vez de ``rfq_url``.
        self.negotiation_url = config.get("negotiation_url")
        self.headers = config.get("headers", {})

    def pull_orders(self) -> List[Dict[str, Any]]:
        if not self.orders_url:
            return []
        try:
            with httpx.Client(timeout=15) as client:
                resp = client.get(self.orders_url, headers=self.headers)
                resp.raise_for_status()
                data = resp.json()
                return data if isinstance(data, list) else [data]
        except Exception:
            return []

    def send_rfq(self, rfq: Dict[str, Any], template: str) -> Dict[str, Any]:
        """Envia RFQ ou negociação via HTTP POST.

        Determina a URL a usar: se o dicionário ``rfq`` contiver a chave
        ``negotiation=True`` e ``self.negotiation_url`` estiver definida,
        envia a solicitação para ``negotiation_url``; caso contrário, usa
        ``rfq_url``. O corpo JSON inclui todos os campos do RFQ mais a
        mensagem gerada a partir do template.
        """
        # Seleciona endpoint
        url = None
        if rfq.get("negotiation") and self.negotiation_url:
            url = self.negotiation_url
        else:
            url = self.rfq_url
        if not url:
            return {"ok": False, "reason": "url_nao_configurada"}
        # Gera mensagem preenchendo todos os campos disponíveis. Fallback para SKU.
        try:
            message = template.format(**rfq)
        except Exception:
            message = template.format(sku=rfq.get("sku"))
        # Monta payload com todos os campos do rfq
        payload: Dict[str, Any] = dict(rfq)
        payload["message"] = message
        try:
            with httpx.Client(timeout=15) as client:
                resp = client.post(url, json=payload, headers=self.headers)
                resp.raise_for_status()
                # Assume que a resposta JSON é desejada
                data = None
                try:
                    data = resp.json()
                except Exception:
                    data = resp.text
                return {"ok": True, "channel": "http", "response": data}
        except Exception as e:
            return {"ok": False, "reason": str(e)}