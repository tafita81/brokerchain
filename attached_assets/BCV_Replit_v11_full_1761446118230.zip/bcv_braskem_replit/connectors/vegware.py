"""Conector de catálogo para a Vegware (Reino Unido).

Vegware é reconhecida por sua linha Nourish™ de embalagens moldadas
em fibra, sem PFAS, certificadas para compostagem doméstica e
industrial. Este conector lê um arquivo JSON de produtos Vegware
adequados para atender às exigências PFAS/EPR【246364944531829†L27-L57】.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from .base import BaseConnector


DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "vegware_products.json")


class VegwareConnector(BaseConnector):
    """Lê o catálogo da Vegware a partir de um arquivo JSON."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []
