"""Conector de catálogo para Dyson Corp (Estados Unidos).

Dyson é fabricante de fixadores e componentes de alta resistência
melted and manufactured in the USA, atendendo ao programa Buy America e
prestando suporte a projetos de infraestrutura. Os produtos possuem
certificações ISO e ASME.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from .base import BaseConnector


DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "dyson_products.json")


class DysonConnector(BaseConnector):
    """Lê o catálogo da Dyson a partir de um arquivo JSON."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []
