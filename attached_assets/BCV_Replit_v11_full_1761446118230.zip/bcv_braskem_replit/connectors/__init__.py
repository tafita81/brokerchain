"""Facilita o carregamento dinâmico de conectores a partir de providers.yaml.

Este módulo centraliza o mapeamento entre o nome do conector (definido em
providers.yaml) e a classe Python correspondente. Conectores adicionais
podem ser importados aqui sem alterar a lógica de business.
"""

from __future__ import annotations

from typing import Type

from .base import BaseConnector
from .email import EmailConnector
from .http_generic import HttpGenericConnector
from .warehouse import WarehouseConnector
from .braskem import BraskemConnector
from .chemgreen import ChemGreenConnector
from .bioleader import BioleaderConnector
from .vegware import VegwareConnector
from .sundance import SundanceConnector
from .sabert import SabertConnector
from .dyson import DysonConnector
from .prestige import PrestigeConnector
from .sancoffee import SancoffeeConnector
from .suzano import SuzanoConnector
from .klabin import KlabinConnector


CONNECTOR_MAP: dict[str, Type[BaseConnector]] = {
    # Conectores de serviços
    "email": EmailConnector,
    "http_generic": HttpGenericConnector,
    "warehouse": WarehouseConnector,
    # Fornecedores PFAS/EPR
    "braskem": BraskemConnector,
    "chemgreen": ChemGreenConnector,
    "bioleader": BioleaderConnector,
    "vegware": VegwareConnector,
    "sundance": SundanceConnector,
    "sabert": SabertConnector,
    # Fornecedores Buy America
    "dyson": DysonConnector,
    "prestige": PrestigeConnector,
    # Fornecedores EUDR
    "sancoffee": SancoffeeConnector,
    "suzano": SuzanoConnector,
    "klabin": KlabinConnector,
}


def get_connector_class(name: str) -> Type[BaseConnector]:
    """Retorna a classe Python associada ao nome do conector."""
    return CONNECTOR_MAP[name]
