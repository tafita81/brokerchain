"""Conector de catálogo para Suzano (Brasil).

Suzano é uma das maiores produtoras de celulose do mundo. A celulose
brasileira exportada por empresas como a Suzano é certificada como livre de
desmatamento desde 1994【537191952811551†L464-L577】. Este conector expõe
produtos de pasta de eucalipto preparados para a EUDR.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from connectors.base import BaseConnector

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "suzano_products.json")


class SuzanoConnector(BaseConnector):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []