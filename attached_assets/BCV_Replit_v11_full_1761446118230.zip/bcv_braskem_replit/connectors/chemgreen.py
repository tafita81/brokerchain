"""Conector de catálogo ChemGreen.

Este conector é um exemplo de outro fornecedor de insumos biodegradáveis e
embalagens sustentáveis, fornecendo produtos alternativos à Braskem.
Os dados estão em um arquivo JSON com informações básicas sobre cada
produto (SKU, nome, descrição, país de origem, se é bio-based, se é
mono-material, etc.). O conector somente fornece listagem de produtos.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from .base import BaseConnector

# Caminho padrão do arquivo de produtos
DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "chemgreen_products.json")


class ChemGreenConnector(BaseConnector):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        # Permite especificar outro arquivo via config
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        """Lê o arquivo de produtos da ChemGreen e retorna uma lista de dicionários."""
        try:
            with open(self.data_file, "r") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []