"""Conector de catálogo para a Bioleader (China).

Este conector lê um arquivo JSON contendo produtos de embalagens e
utensílios da Bioleader. A Bioleader, sediada em Xiamen, produz
itens de bagasse e amido de milho com múltiplas certificações
(OK Compost, EN13432, ASTM D6400, FDA, ISO 9001/14001, BRCGS) e
capacidade de produção de 100 milhões de unidades mensais【732713063189336†L40-L83】.
Todos os produtos são PFAS‑free e compostáveis, adequados para
atender às exigências de PFAS/EPR.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from .base import BaseConnector


DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "bioleader_products.json")


class BioleaderConnector(BaseConnector):
    """Lê o catálogo da Bioleader a partir de um arquivo JSON.

    Use ``providers.yaml`` para configurar o caminho do arquivo JSON via
    ``products_file`` se desejar sobrescrever o valor padrão.
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []
