"""Conector de catálogo para Klabin (Brasil).

Klabin é outro gigante da celulose e papel no Brasil, com diversas
certificações de manejo florestal sustentável. Para fins de EUDR, seus
produtos são rastreáveis e preparados para exportação para a União Europeia.
"""

from __future__ import annotations

import json
import os
from typing import List, Dict, Any

from connectors.base import BaseConnector

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "klabin_products.json")


class KlabinConnector(BaseConnector):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.data_file = config.get("products_file", DATA_PATH)

    def list_products(self) -> List[Dict[str, Any]]:
        try:
            with open(self.data_file, "r", encoding="utf-8") as fp:
                data = json.load(fp)
                return data if isinstance(data, list) else []
        except Exception:
            return []